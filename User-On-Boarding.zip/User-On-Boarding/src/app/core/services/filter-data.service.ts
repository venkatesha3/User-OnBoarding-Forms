import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { FilterparamsModel } from '../components/user-details/filter-params.model';

@Injectable({
  providedIn: 'root'
})
export class FilterDataService {
  filterParams: FilterparamsModel;
  filterParams$: Subject<FilterparamsModel>;
  clearFilter$: Subject<boolean>;
  viewBurgermenu$: Subject<boolean>;
  constructor() {
    this.filterParams = new FilterparamsModel();
    this.filterParams$ = new Subject<FilterparamsModel>();
    this.clearFilter$ = new Subject<boolean>();
    this.viewBurgermenu$ = new Subject<boolean>();
  }

}
