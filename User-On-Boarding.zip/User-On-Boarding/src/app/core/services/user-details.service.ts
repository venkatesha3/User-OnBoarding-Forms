import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { UserDataModel } from '../model/user-data.model';

@Injectable({
  providedIn: 'root'
})
export class UserDetailsService {
  private readonly userData: Array<UserDataModel>;
  private readonly userData$: BehaviorSubject<Array<UserDataModel>>;
  constructor() {
    this.userData = new Array<UserDataModel>();
    this.userData$ = new BehaviorSubject<Array<UserDataModel>>(null);
  }
  setUserData(details) {
    this.userData.push(details)
    this.userData$.next(this.userData);
  }
  getUserData(): Observable<Array<UserDataModel>> {
    return this.userData$.asObservable();
  }
}
