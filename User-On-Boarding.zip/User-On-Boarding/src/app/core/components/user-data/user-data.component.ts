import { Component, OnInit } from '@angular/core';
import { ActivatedRouteSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { UserDataModel } from '../../model/user-data.model';
import { FilterDataService } from '../../services/filter-data.service';
import { UserDetailsService } from '../../services/user-details.service';

@Component({
  selector: 'app-user-data',
  templateUrl: './user-data.component.html',
  styleUrls: ['./user-data.component.scss']
})
export class UserDataComponent implements OnInit {
  searchText: string;
  userData: Array<UserDataModel>;
  filteredUserData: Array<UserDataModel>;
  constructor(private userDetailsService: UserDetailsService, private router: Router,
    private filterDataService: FilterDataService) {
    this.filterDataService.viewBurgermenu$.next(true);
  }

  ngOnInit(): void {

    this.getData();
    this.filterDataService.filterParams$.subscribe(res => {
      this.filteredUserData = this.userData.filter(item => {
        return (
          (res?.boardType) ? item?.boardType?.toLowerCase() == res.boardType.toLowerCase() : this.userData &&
            (res?.qualification?.length > 0) ? this.getQualificationFilteredData(item.qualification, res.qualification) : this.userData);
      })
    })
    this.filterDataService.clearFilter$.subscribe(res => this.clearFilter())
  }
  goToUserForm() {
    this.router.navigate(["user-details"]);
  }
  filterData() {
    if (this.searchText) {
      this.filteredUserData = this.userData.filter(item => {
        return item.userName?.toLowerCase().includes(this.searchText?.toLowerCase()) ||
          item.boardType?.toLowerCase() == this.searchText?.toLowerCase() ||
          this.getQualificationFilteredData(item.qualification)
      })
    } else {
      this.clearFilter();
    }
  }
  getData() {
    this.userDetailsService.getUserData().subscribe(res => this.filteredUserData = this.userData = res);
  }
  clearFilter() {
    this.getData();
  }
  getQualificationFilteredData(qalItems, filterItems = null) {
    if (filterItems && filterItems.length > 0) {
      return filterItems.sort().every(val => qalItems.sort().includes(val));
    } else {
      return (qalItems.findIndex(item => item?.toLowerCase() === this.searchText?.toLowerCase())) == -1 ? false : true;
    }
  }
}
