import { Component, ElementRef, OnInit, Renderer2, ViewChild, ViewContainerRef } from "@angular/core";
import { ActivatedRoute, ActivatedRouteSnapshot, Router } from "@angular/router";
import { FilterDataService } from "../../services/filter-data.service";
import { FilterparamsModel } from "../user-details/filter-params.model";



@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.scss']
})
export class NavBarComponent implements OnInit{
  viewpage: boolean = false;
  @ViewChild('mySidenav', { static: false }) mySidenav: ElementRef;
  @ViewChild('main', { static: false }) main: ElementRef;
  qualifications: any[];
  boardType: string;
  constructor(private renderer: Renderer2,
    private filterDataService: FilterDataService,
  ) {
    this.setDefaultFilterData();
  
  }
  ngOnInit() {
  this.filterDataService.viewBurgermenu$.subscribe(res=>this.viewpage=res);
  }
  setDefaultFilterData() {
    this.boardType = "";
    this.qualifications = [
      { name: "Post Graduation", value: false },
      { name: "Graduation", value: false },
      { name: "Primary Education", value: false },
    ];
    this.filterDataService.clearFilter$.next(true);
  }
  onFilterSearch() {
    const filterparamsModel = new FilterparamsModel();
    filterparamsModel.boardType = this.boardType;
    filterparamsModel.qualification = <[string]>this.qualifications.filter(item => {
      if (item.value) return item
    }).map(item => item.name);
    console.log(filterparamsModel);
    this.filterDataService.filterParams$.next(filterparamsModel);

  }
  setQualifications(event, i) {

    this.qualifications[i].value = event?.target?.checked;
  }
  openNav() {
    this.renderer.setStyle(this.mySidenav.nativeElement, "width", "250px");
    this.renderer.setStyle(this.main.nativeElement, "marginLeft", "250px");

  }

  closeNav() {
    this.renderer.setStyle(this.mySidenav.nativeElement, "width", "0");
    this.renderer.setStyle(this.main.nativeElement, "marginLeft", "0");

  }
}
